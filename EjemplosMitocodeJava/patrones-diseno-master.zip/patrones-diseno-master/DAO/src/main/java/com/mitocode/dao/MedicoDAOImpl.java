package com.mitocode.dao;

import java.util.List;

import com.mitocode.model.Medico;

public class MedicoDAOImpl implements MedicoDAO{

	@Override
	public List<Medico> listarTodos() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Medico leerPorId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void registrar(Medico medico) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actualizar(Medico medico) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void eliminar(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void curar() {
		// TODO Auto-generated method stub
		
	}

}
