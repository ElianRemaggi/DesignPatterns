package com.mitocode.dao;

import com.mitocode.model.Persona;

public interface PersonaDAO extends CRUD<Persona>{

	void mostrarNombre();
	
}
