package com.mitocode.dao;

import com.mitocode.model.Medico;

public interface MedicoDAO extends CRUD<Medico>{

	void curar();

}
