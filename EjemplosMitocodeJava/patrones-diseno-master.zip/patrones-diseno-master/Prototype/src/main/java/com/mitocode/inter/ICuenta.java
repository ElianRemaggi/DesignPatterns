package com.mitocode.inter;

public interface ICuenta extends Cloneable {

	ICuenta clonar();

}
