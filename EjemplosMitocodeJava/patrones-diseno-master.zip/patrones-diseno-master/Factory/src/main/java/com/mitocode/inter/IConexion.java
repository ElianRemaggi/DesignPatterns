package com.mitocode.inter;

public interface IConexion {

	void conectar();
	void desconectar();

}
