package com.mitocode.commands;

//Command
@FunctionalInterface
public interface IOperacion {

	void execute();
}
