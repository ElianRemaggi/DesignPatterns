package com.mitocode.inter.impl;

import com.mitocode.inter.IConexionREST;

public class ConexionRESTVentas implements IConexionREST{

	@Override
	public void leerURL(String url) {
		// TODO Auto-generated method stub
		
	}

}
