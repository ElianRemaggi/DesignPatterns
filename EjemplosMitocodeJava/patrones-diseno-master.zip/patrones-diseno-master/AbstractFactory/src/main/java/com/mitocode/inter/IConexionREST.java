package com.mitocode.inter;

public interface IConexionREST {

	void leerURL(String url);	
}
