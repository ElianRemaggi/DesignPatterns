package com.mitocode.inter;

public interface IConexionBD {

	void conectar();
	void desconectar();
}
