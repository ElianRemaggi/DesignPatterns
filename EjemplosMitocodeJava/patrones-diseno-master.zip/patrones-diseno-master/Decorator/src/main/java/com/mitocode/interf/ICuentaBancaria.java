package com.mitocode.interf;

import com.mitocode.model.Cuenta;

public interface ICuentaBancaria {

	void abrirCuenta(Cuenta c);

}
