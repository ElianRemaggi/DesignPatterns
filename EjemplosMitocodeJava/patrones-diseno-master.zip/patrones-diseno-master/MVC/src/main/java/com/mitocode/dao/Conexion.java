package com.mitocode.dao;

public interface Conexion {
	
	void conectar();

}
