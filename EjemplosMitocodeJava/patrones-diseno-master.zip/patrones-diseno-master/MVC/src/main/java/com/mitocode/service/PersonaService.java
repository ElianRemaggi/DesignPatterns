package com.mitocode.service;

import com.mitocode.dao.CRUD;
import com.mitocode.model.Persona;

public interface PersonaService extends CRUD<Persona>{

}
