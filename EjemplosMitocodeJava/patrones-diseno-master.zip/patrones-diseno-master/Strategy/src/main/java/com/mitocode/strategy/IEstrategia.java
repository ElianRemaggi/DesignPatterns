package com.mitocode.strategy;

public interface IEstrategia {

	void analizar();
}
