package com.mitocode.dao;

public interface IConexion {

	void conectar();
}
